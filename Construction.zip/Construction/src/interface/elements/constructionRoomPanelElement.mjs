const { loadModule } = mod.getContext(import.meta);

const { getRielkLangString, templateRielkLangString } = await loadModule('src/language/translationManager.mjs');

await loadModule('src/interface/elements/constructionEfficiencyIconTooltipElement.mjs');
await loadModule('src/interface/elements/constructionEfficiencyIconElement.mjs');

class ConstructionRoomPanelElement extends HTMLElement {
    constructor() {
        super();
        this.noneSelected = true;
        this.selectedFixture = undefined;
        this.fixtureNavs = new Map();
        this._content = new DocumentFragment();
        this._content.append(getTemplateNode('rielk-construction-room-panel-template'));
        this.header = getElementFromFragment(this._content, 'header', 'div');
        this.eyeIcon = getElementFromFragment(this._content, 'eye-icon', 'i');
        this.imageContainer = getElementFromFragment(this._content, 'image-container', 'div');
        this.builtProgressContainer = getElementFromFragment(this._content, 'built-progress-container', 'div');
        this.ingredientsContainer = getElementFromFragment(this._content, 'ingredients-container', 'div');
        this.grantsContainer = getElementFromFragment(this._content, 'grants-container', 'div');
        this.detailsContainer = getElementFromFragment(this._content, 'details-container', 'div');
        this.extraDetailsContainer = getElementFromFragment(this._content, 'extra-details-container', 'div');
        this.roomName = getElementFromFragment(this._content, 'room-name', 'span');
        this.targetContainer = getElementFromFragment(this._content, 'target-container', 'div');
        this.productPreservation = getElementFromFragment(this._content, 'product-preservation', 'preservation-icon');
        this.productEfficiency = getElementFromFragment(this._content, 'product-efficiency', 'efficiency-icon');
        this.infoContainer = getElementFromFragment(this._content, 'info-container', 'div');
        this.infoBoxName = getElementFromFragment(this._content, 'product-name', 'span');
        this.infoBoxImage = getElementFromFragment(this._content, 'product-image', 'img');
        this.startButton = getElementFromFragment(this._content, 'start-button', 'button');
        this.upgradesButton = getElementFromFragment(this._content, 'upgrades-button', 'button');
        this.builtProgressText = getElementFromFragment(this._content, 'built-progress-text', 'small');
        this.builtProgressBar = getElementFromFragment(this._content, 'built-progress-bar', 'progress-bar');
        this.requires = getElementFromFragment(this._content, 'requires', 'requires-box');
        this.haves = getElementFromFragment(this._content, 'haves', 'haves-box');
        this.grants = getElementFromFragment(this._content, 'grants', 'grants-box');
        this.progressBar = getElementFromFragment(this._content, 'progress-bar', 'progress-bar');
        this.buildContainer = getElementFromFragment(this._content, 'build-container', 'div');
        this.interval = getElementFromFragment(this._content, 'interval', 'interval-icon');
    }
    connectedCallback() {
        this.appendChild(this._content);
        this.noneSelected ? this.grants.setUnselected() : this.grants.setSelected();

        window.addEventListener('resize', () => {
            const width = parseFloat(getComputedStyle(this.extraDetailsContainer).width);
            this.setdetailscontainer(width);

        });
        this.grants.hideMastery();
        /* if ((window.innerWidth <= 1920 && window.innerWidth >= 1350) || (window.innerWidth <= 860 && window.innerWidth >= 767))
             for (const icon of [this.productPreservation, this.productEfficiency]) {
                 const btn = icon.querySelector('.info-icon');
                 if (btn) {
                     btn.classList.remove('m-2');
                     btn.classList.add('mb-2');
                     btn.classList.add('mt-2');
                     if (i === 1) btn.classList.add('ms-1');
                 }
             }*/

    }
    setdetailscontainer(detailwidth) {
        if (this.noneSelected /*|| this.productEfficiency.classList.contains('d-none')*/) return;
        if (detailwidth < 220) {
            this.extraDetailsContainer.parentElement.style.marginLeft = '-14px';
            this.extraDetailsContainer.parentElement.style.marginRight = '-14px';
            this.extraDetailsContainer.innerHTML = '';
            this.extraDetailsContainer.className = 'icon-size-48';
            this.extraDetailsContainer.style.display = 'flex';
            this.extraDetailsContainer.style.flexDirection = 'column';
            this.extraDetailsContainer.style.alignItems = 'flex-start';
            this.extraDetailsContainer.style.padding = '0';
            this.extraDetailsContainer.style.margin = '0';

            const iconRow = document.createElement('div');
            iconRow.style.display = 'flex';
            iconRow.style.flexWrap = 'nowrap';
            iconRow.style.justifyContent = 'flex-start';
            iconRow.style.alignItems = 'center';
            iconRow.style.gap = '4px';
            iconRow.style.margin = '0';
            [this.productPreservation, this.productEfficiency].forEach(icon => {
                const inner = icon.querySelector('.btn-light');
                if (inner) { inner.classList.remove('m-2'); inner.classList.add('mr-2'); inner.classList.add('mb-2'); }
            });

            iconRow.append(this.productPreservation, this.productEfficiency);

            iconRow.append(this.productPreservation, this.productEfficiency);
            this.extraDetailsContainer.append(iconRow, this.upgradesButton);
        }
        else {
            this.extraDetailsContainer.parentElement.style.marginLeft = '';
            this.extraDetailsContainer.parentElement.style.marginRight = '';
            this.extraDetailsContainer.style.display = '';
            this.extraDetailsContainer.style.flexDirection = '';
            this.extraDetailsContainer.style.alignItems = '';
            this.extraDetailsContainer.style.gap = '';
            this.extraDetailsContainer.innerHTML = '';
            this.extraDetailsContainer.className = 'row icon-size-48';
            const preservationInner = this.productPreservation.querySelector('.btn-light');
            if (preservationInner) preservationInner.style.marginLeft = '';
            this.extraDetailsContainer.append(
                this.upgradesButton,
                this.productPreservation,
                this.productEfficiency
            );
            [this.productPreservation, this.productEfficiency, this.upgradesButton].forEach(el => {
                el.style.flex = '';
                el.style.alignSelf = '';
                el.style.width = '';
                el.style.height = '';
            });
        }

    }
    setRoom(room, construction) {
        this.roomName.textContent = room.name;
        this.header.onclick = () => construction.ui.onRoomHeaderClick(room, construction);
        room.fixtures.forEach((fixture) => {
            const fixtureNav = createElement('rielk-construction-fixture-nav', {
                parent: this.targetContainer
            });
            fixtureNav.setFixture(fixture, construction);
            this.fixtureNavs.set(fixture, fixtureNav);
        }
        );
    }
    hide() {
        hideElement(this.targetContainer);
        hideElement(this.infoContainer);
        this.eyeIcon.classList.remove('fa-eye');
        this.eyeIcon.classList.add('fa-eye-slash');
    }
    show() {
        showElement(this.targetContainer);
        showElement(this.infoContainer);
        this.eyeIcon.classList.remove('fa-eye-slash');
        this.eyeIcon.classList.add('fa-eye');
    }
    updateFixturesForLevel(construction, room) {
        this.fixtureNavs.forEach((fixtureNav, fixture) => {
            if (construction.level >= fixture.level && construction.abyssalLevel >= fixture.abyssalLevel) {
                fixtureNav.setUnlocked(() => this.selectFixture(room, fixture, construction));
            } else {
                fixtureNav.setLocked(fixture, construction);
            }
        }
        );
    }
    updateFixtureButtons(game) {
        this.fixtureNavs.forEach((nav, fixture) => {
            nav.updateFixture(fixture, game);
        }
        );
    }
    selectFixture(room, fixture, construction) {
        if (!construction.ui.onFixturePanelSelection(fixture, room, construction))
            return;
        this.selectedFixture = fixture;
        this.updateRoomInfo(construction);

        this.startButton.onclick = () => construction.toggleBuilding(room, fixture);
        if (construction.ui.constructionHouseMenu.roomUnlocksPanel.classList.contains('d-none'))
            this.upgradesButton.onclick = () => construction.ui.showFixtureUnlocks(room, fixture, construction);
        else
            this.upgradesButton.onclick = () => construction.ui.hideFixtureUnlocks(room, fixture, construction);

        const interval = construction.getFixtureInterval(fixture);
        this.interval.setInterval(interval, construction.getIntervalSources(fixture));

    }
    showFixtureUnlocks(room, fixture, construction) {
        this.upgradesButton.textContent = getRielkLangString('MENU_TEXT_SHOW_GO_BACK');
        this.upgradesButton.onclick = () => construction.ui.hideFixtureUnlocks(room, fixture, construction);
    }
    hideFixtureUnlocks(room, fixture, construction) {
        this.upgradesButton.textContent = getRielkLangString('MENU_TEXT_SHOW_UPGRADES');
        this.upgradesButton.onclick = () => construction.ui.showFixtureUnlocks(room, fixture, construction);
        requestAnimationFrame(() => window.scrollTo(0, this.scrollBeforePanel));
    }
    updateRoomInfo(construction) {
        if (this.selectedFixture !== undefined) {
            showElement(this.imageContainer);
            showElement(this.builtProgressContainer);
            showElement(this.ingredientsContainer);
            showElement(this.grantsContainer);
            showElement(this.buildContainer);
            showElement(this.extraDetailsContainer);
            showElement(this.productPreservation);
            showElement(this.productEfficiency);
            requestAnimationFrame(() => {
                const detailWidth = parseFloat(getComputedStyle(this.extraDetailsContainer).width);
                this.setdetailscontainer(detailWidth);
            });

            this.detailsContainer.classList.remove('col-12');
            this.detailsContainer.classList.remove('text-center');
            this.detailsContainer.classList.add('col-8');
            this.updateFixtureInfo(construction, this.selectedFixture);
        } else {
            this.infoBoxName.textContent = '-';
            hideElement(this.imageContainer);
            hideElement(this.builtProgressContainer);
            hideElement(this.ingredientsContainer);
            hideElement(this.grantsContainer);
            hideElement(this.buildContainer);
            hideElement(this.extraDetailsContainer);
            this.detailsContainer.classList.remove('col-8');
            this.detailsContainer.classList.add('col-12');
            this.detailsContainer.classList.add('text-center');
        }
    }
    updateFixtureInfo(construction, fixture) {
        this.noneSelected = false;
        this.infoBoxName.textContent = fixture.name;
        this.infoBoxImage.src = fixture.media;

        const fixtureRecipe = fixture.currentRecipe;
        if (fixtureRecipe == undefined || fixtureRecipe.level > construction.level) {
            hideElement(this.builtProgressContainer);
            hideElement(this.ingredientsContainer);
            hideElement(this.grantsContainer);
            hideElement(this.buildContainer);
            hideElement(this.productPreservation);
            hideElement(this.productEfficiency);

            return;
        }

        requestAnimationFrame(() => {
            const detailWidth = parseFloat(getComputedStyle(this.extraDetailsContainer).width);
            this.setdetailscontainer(detailWidth);
        });


        const progress = fixture.percentProgress;
        this.builtProgressText.textContent = templateRielkLangString('MENU_TEXT_PARTIAL_BUILT_PROGRESS', {
            currentValue: `${formatNumber(fixture.progress)}`,
            maxValue: `${formatNumber(fixtureRecipe.actionCost)}`,
            percent: progress == undefined ? '' : `(${formatPercent(progress, 2)})`,
        });
        this.builtProgressBar.setFixedPosition(progress == undefined ? 0 : progress);
        this.requires.setItemsFromRecipe(fixtureRecipe);
        const label = this.requires.querySelector('h5 > lang-string[lang-id="MENU_TEXT_REQUIRES"]');
        if (label) label.textContent = getRielkLangString('MENU_TEXT_REMAINING');
        this.haves.setItemsFromRecipe(fixtureRecipe, construction.game);
        const requireIcons = this.requires.querySelectorAll('item-quantity-icon');
        const haveIcons = this.haves.querySelectorAll('item-current-icon');

        requireIcons.forEach((icon, i) => {
            const qtyEl = icon.querySelector("small.badge-pill");
            const haveQtyEl = haveIcons[i]?.querySelector("small.badge-pill");
            const have = parseInt(haveQtyEl.textContent.replace(/,/g, ""), 10);
            const base = parseInt(qtyEl.textContent.replace(/,/g, ""), 10);

            if (!isNaN(base) && !isNaN(have)) {
                let totalCost = base * (fixtureRecipe.actionCost - fixture.progress);
                qtyEl.textContent = formatNumber(Math.max(base, totalCost));

                if (have >= base && have < totalCost) {
                    qtyEl.parentElement?.parentElement.classList.add('border-item-danger');
                    haveQtyEl.parentElement?.parentElement.classList.add('border-item-danger');
                } else {
                    qtyEl.parentElement?.parentElement.classList.remove('border-item-danger');
                    haveQtyEl.parentElement?.parentElement.classList.remove('border-item-danger');
                }
            }
        });

        // --- CURRENCY ICONS ---
        const requireCurrencyIcons = this.requires.querySelectorAll('currency-quantity-icon');
        const haveCurrencyIcons = this.haves.querySelectorAll('currency-current-icon');

        requireCurrencyIcons.forEach((icon, i) => {
            const qtyEl = icon.querySelector("small.badge-pill");
            const haveQtyEl = haveCurrencyIcons[i]?.querySelector("small.badge-pill");
            const have = parseInt(haveQtyEl.textContent.replace(/,/g, ""), 10);
            const base = parseInt(qtyEl.textContent.replace(/,/g, ""), 10);

            if (!isNaN(base) && !isNaN(have)) {
                let totalCost = base * (fixtureRecipe.actionCost - fixture.progress);
                qtyEl.textContent = formatNumber(Math.max(base, totalCost));

                if (have >= base && have < totalCost) {
                    qtyEl.parentElement?.parentElement.classList.add('border-item-danger');
                    haveQtyEl.parentElement?.parentElement.classList.add('border-item-danger');
                } else {
                    qtyEl.parentElement?.parentElement.classList.remove('border-item-danger');
                    haveQtyEl.parentElement?.parentElement.classList.remove('border-item-danger');
                }
            }
        });
        this.grants.setSelected();
        this.grants.xpIcon.setXP(Math.floor(construction.modifyXP(fixtureRecipe.baseExperience)), fixtureRecipe.baseExperience);
        this.grants.updateAbyssalGrants(Math.floor(construction.modifyAbyssalXP(fixtureRecipe.baseAbyssalExperience)), fixtureRecipe.baseAbyssalExperience);
        this.grants.setSources(construction, fixtureRecipe);
        this.grants.hideMastery();
        this.productPreservation.setChance(construction.getPreservationChance(fixtureRecipe), construction.getPreservationCap(fixtureRecipe), construction.getPreservationSources(fixtureRecipe));
        this.productEfficiency.setChance(
            construction.getEfficiencyChance(fixtureRecipe),
            construction.getEfficiencyPotencyMultiplier(fixtureRecipe),
            construction.getEfficiencyCostMultiplier(fixtureRecipe),
            construction.getEfficiencyChancePotencySources(fixtureRecipe), "build");
    }
}
window.customElements.define('rielk-construction-room-panel', ConstructionRoomPanelElement);

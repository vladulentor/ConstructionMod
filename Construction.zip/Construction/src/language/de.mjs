export const language = {
    'SKILL_NAME_Construction': 'Konstruktion',

    'MENU_TEXT_SELECT_CONSTRUCTION_CATEGORY': 'Baukategorie Auswählen',
    'MENU_TEXT_CONSTRUCT': 'Konstruieren',
    'MENU_TEXT_BUILD': 'Bauen',
    'MENU_TEXT_BUILT_PROGRESS': 'Upgrade: ${currentValue}/${maxValue}',
    'MENU_TEXT_PARTIAL_BUILT_PROGRESS': '${currentValue}/${maxValue} ${percent}',
    'MENU_TEXT_SHOW_UPGRADES': 'Upgrades',
    'MENU_TEXT_SHOW_GO_BACK': 'Geh zurück',
    'MENU_TEXT_REMAINING': 'Verbleibende Kosten',
    'MENU_TEXT_SHOW_ALL_ACTIVE_MODIFIERS': 'Alle aktiven Modifikatoren anzeigen',
    'MENU_TEXT_ALL_ACTIVE_CONSTRUCTION_MODIFIERS': 'Alle aktiven Konstruktionsmodifikatoren',
    'MENU_VIEW_HOUSE_TIERS': 'Hausstufen-Boni anzeigen',
    'MENU_UNLOCKED_MASTERY_FOR_TIER': 'Deine Hausstufe ist auf <span class="construction-success">Stufe ${tiername}</span> gestiegen',
    'MENU_HOUSE_TIER_BONUS_UNLOCKED': 'Hausstufen-Bonus freigeschaltet!',
    'MENU_HOUSE_COMPLETION': 'Hausvollendung',
    'MENU_HOUSE': "Haus",
    'MENU_TIER': 'Stufe ${tiername}',
    'MENU_BUILT': 'Gebaut',
        'MENU_FIXTURES':'Einbauten',

    'MENU_TEXT_WHAT_ARE_HOUSE_TIERS': 'Was sind Hausstufen?',
    'MENU_TEXT_HOUSE_TIER_EXPLANATION_1': 'Die Stufe deines Hauses beginnt bei 0. Wenn du Möbel baust und jeden Raum füllst, wird die Stufe deines Hauses steigen.</span>',
    'MENU_TEXT_HOUSE_TIER_EXPLANATION_2': 'Wenn alle Räume Möbel der erforderlichen Stufe oder höher enthalten, steigt dein Haus-Level. Du schaltest permanente Bau-Boni frei und erhältst Materialien.',
    'MENU_TEXT_REWARDS': 'Belohnungen',


    'SHOP_NAME_Construction_Skillcape': 'Umhang der Konstruktion',

    'PET_NAME_ChuckTheForeman': 'Chuck der Vorarbeiter',
    'PET_NAME_Scoobs': 'Scoobs',


    'ITEM_NAME_Construction_Skillcape': 'Umhang der Konstruktion',
    'ITEM_NAME_Builders_Hat': 'Bauarbeiterhut',
    'ITEM_NAME_Builders_Body': 'Bauherrenoberteil',
    'ITEM_NAME_Builders_Leggings': 'Bauarbeiterbeinlinge',
    'ITEM_NAME_Builders_Boots': 'Bauarbeiterstiefel',

    'ITEM_NAME_Iron_Nails': 'Eisennägel',
    'ITEM_NAME_Steel_Nails': 'Stahlnägel',
    'ITEM_NAME_Mithril_Nails': 'Mithrilnägel',
    'ITEM_NAME_Adamantite_Nails': 'Adamantnägel',
    'ITEM_NAME_Dragonite_Nails': 'Drachennägel',

    'ITEM_NAME_Normal_Planks': 'Normale Bretter',
    'ITEM_NAME_Oak_Planks': 'Eichenbretter',
    'ITEM_NAME_Teak_Planks': 'Teakholzbretter',
    'ITEM_NAME_Mahogany_Planks': 'Mahagonibretter',
    'ITEM_NAME_Magic_Planks': 'Magische Bretter',

    'ITEM_NAME_Flower_Pots_Token_1': 'Blumentöpfe: Stufe 1',
    'ITEM_NAME_Flower_Pots_Token_2': 'Blumentöpfe: Stufe 2',
    'ITEM_NAME_Flower_Pots_Token_3': 'Blumentöpfe: Stufe 3',
    'ITEM_NAME_Flower_Pots_Token_4': 'Blumentöpfe: Stufe 4',
    'ITEM_NAME_Flower_Pots_Token_5': 'Blumentöpfe: Stufe 5',


    'ITEM_DESCRIPTION_Builders_Hat': '+2 % Fertigkeits-EP in Konstruktion.<br><span class=\"text-warning\">Wenn alle vier Teile des Kostüms der brennenden Menschheit ausgerüstet sind: +8 % Konstruktion-Meisterungs-EP.</span>',
    'ITEM_DESCRIPTION_Builders_Body': '+2 % Fertigkeits-EP in Konstruktion.<br><span class=\"text-warning\">Wenn alle vier Teile des Kostüms der brennenden Menschheit ausgerüstet sind: +8 % Konstruktion-Meisterungs-EP.</span>',
    'ITEM_DESCRIPTION_Builders_Leggings': '+2 % Fertigkeits-EP in Konstruktion.<br><span class=\"text-warning\">Wenn alle vier Teile des Kostüms der brennenden Menschheit ausgerüstet sind: +8 % Konstruktion-Meisterungs-EP.</span>',
    'ITEM_DESCRIPTION_Builders_Boots': '+2 % Fertigkeits-EP in Konstruktion.<br><span class=\"text-warning\">Wenn alle vier Teile des Kostüms der brennenden Menschheit ausgerüstet sind: +8 % Konstruktion-Meisterungs-EP.</span>',

        'TOAST_FIXTURE_COMPLETE':'Du hast deine ${fixtureName} fertiggestellt!',

    'MODIFIER_DATA_farmingTreeSeedReturn': '+${value}% chance, beim Ernten einen Baumsamen in der Landwirtschaft zurückzugewinnen',
    'MODIFIER_DATA_decreaseConstructionActionsToUpgrade': '-${value}% Aktionen erforderlich, um Möbel im Bauwesen zu erstellen',
    'MODIFIER_DATA_increaseConstructionActionsToUpgrade': '+${value}% Aktionen erforderlich, um Möbel im Bauwesen zu erstellen',

    'DESCRIPTION_ADDS_ITEM': 'Gibt ${itemQuantity} ${itemName} ${itemImage}',
    'DESCRIPTION_UNLOCKS_PLOT': 'Schaltet 1 ${plotCategory} Feld in der Landwirtschaft frei',

    'TOASTS_MATERIALS_REQUIRED_TO_BUILD': 'Sie haben nicht die erforderlichen Materialien, um das zu bauen',

    'MASTERY_BONUS_ Construction_ 0': 'Schalte die Effekte der Stufe 1 des Einrichtungsgegenstands frei.',
    'MASTERY_BONUS_ Construction_ 1': 'Schalte die Effekte der Stufe 2 des Einrichtungsgegenstands frei.',
    'MASTERY_BONUS_ Construction_ 2': 'Schalte die Effekte der Stufe 3 des Einrichtungsgegenstands frei.',
    'MASTERY_BONUS_ Construction_ 3': 'Schalte die Effekte der Stufe 4 des Einrichtungsgegenstands frei.',
    'MASTERY_BONUS_ Construction_ 4': 'Schalte die Effekte der Stufe 5 des Einrichtungsgegenstands frei.',

    'SKILL_CATEGORY_ Construction_ Materials': 'Baumaterialien',
    'SKILL_CATEGORY_ Construction_ House': 'Möbel',

    'CONSTRUCTION_ROOM_NAME_ Bedroom': 'Schlafzimmer',
    'CONSTRUCTION_ROOM_NAME_ Garden': 'Garten',
    'CONSTRUCTION_ROOM_NAME_ Kitchen': 'Küche',
    'CONSTRUCTION_ROOM_NAME_ Laboratory': 'Labor',
    'CONSTRUCTION_ROOM_NAME_ Outpost': 'Vorposten',
    'CONSTRUCTION_ROOM_NAME_ Refectory': 'Refektorium',
    'CONSTRUCTION_ROOM_NAME_ Training_Room': 'Schulungsraum',
    'CONSTRUCTION_ROOM_NAME_ Workshop': 'Werkstatt',

    'CONSTRUCTION_FIXTURE_OF_TIER': '${fixtureName}: Stufe ${tier}',
    'CONSTRUCTION_FIXTURE_NAME_ Apparatus': 'Gerät',
    'CONSTRUCTION_FIXTURE_NAME_ Archery_Range': 'Bogenschießanlage',
    'CONSTRUCTION_FIXTURE_NAME_ Black_Market': 'Schwarzmarkt',
    'CONSTRUCTION_FIXTURE_NAME_ Desk': 'Schreibtisch',
    'CONSTRUCTION_FIXTURE_NAME_ Dragon_Statue': 'Drachenstatue',
    'CONSTRUCTION_FIXTURE_NAME_ Fire_Pit': 'Feuerstelle',
    'CONSTRUCTION_FIXTURE_NAME_ Flower_Pots': 'Blumentöpfe',
    'CONSTRUCTION_FIXTURE_NAME_ Forge': 'Schmiede',
    'CONSTRUCTION_FIXTURE_NAME_ Fridge': 'Vorratskammer',
    'CONSTRUCTION_FIXTURE_NAME_ Jungle_Gym': 'Klettergerüst',
    'CONSTRUCTION_FIXTURE_NAME_ Lake': 'See',
    'CONSTRUCTION_FIXTURE_NAME_ Mines': 'Mine',
    'CONSTRUCTION_FIXTURE_NAME_ Orchard': 'Wald',
    'CONSTRUCTION_FIXTURE_NAME_ Oven': 'Ofen',
    'CONSTRUCTION_FIXTURE_NAME_ Prayer_Altar': 'Gebetsaltar',
    'CONSTRUCTION_FIXTURE_NAME_ Rune_Altar': 'Runenaltar',
    'CONSTRUCTION_FIXTURE_NAME_ Spell_Library': 'Zauberbibliothek',
    'CONSTRUCTION_FIXTURE_NAME_ Storage_Chest': 'Aufbewahrungskiste',
    'CONSTRUCTION_FIXTURE_NAME_ Telescope': 'Teleskop',
    'CONSTRUCTION_FIXTURE_NAME_ Tool_Rack': 'Werkzeugkasten',
    'CONSTRUCTION_FIXTURE_NAME_ Training_Dummy': 'Trainingspuppe',
    'CONSTRUCTION_FIXTURE_NAME_ Trapping_Hut': 'Trapperhütte',
    'CONSTRUCTION_FIXTURE_NAME_ Wardrobe': 'Kleiderschrank',
    'CONSTRUCTION_FIXTURE_NAME_ Worktable': 'Werkbank'
}    

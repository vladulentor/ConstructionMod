export const language = {
    'SKILL_NAME_Construction': 'Construction',

    'MENU_TEXT_SELECT_CONSTRUCTION_CATEGORY': 'Sélectionner la Catégorie de Construction',
    'MENU_TEXT_CONSTRUCT': 'Sonstruire',
    'MENU_TEXT_BUILD': 'Construire',
    'MENU_TEXT_BUILT_PROGRESS': 'Mise à Niveau: ${currentValue}/${maxValue}',
    'MENU_TEXT_PARTIAL_BUILT_PROGRESS': '${currentValue}/${maxValue} ${percent}',
    'MENU_TEXT_SHOW_UPGRADES': 'Mises à Niveau',
    'MENU_TEXT_SHOW_GO_BACK': 'Retourner',
    'MENU_TEXT_REMAINING': 'Coûts Restants',
    'MENU_TEXT_SHOW_ALL_ACTIVE_MODIFIERS': 'Voir tous les Modificateurs Actifs',
    'MENU_TEXT_ALL_ACTIVE_CONSTRUCTION_MODIFIERS': 'Tous les Modificateurs de Construction Actifs',
    'MENU_VIEW_HOUSE_TIERS': 'Afficher les bonus des niveaux de maison',
    'MENU_UNLOCKED_MASTERY_FOR_TIER': 'Le niveau de votre maison est passé à <span class="construction-success">Niveau ${tiername}</span>',
    'MENU_HOUSE_TIER_BONUS_UNLOCKED': 'Bonus de niveau de maison débloqué !',
    'MENU_HOUSE_COMPLETION': 'Complétion de la maison',
    'MENU_HOUSE': "Maison",
    'MENU_BUILT': 'Construit',
        'MENU_FIXTURES':'Aménagements',

    'MENU_TIER': 'Niveau ${tiername}',
    'MENU_TEXT_WHAT_ARE_HOUSE_TIERS': 'Qu\'est-ce que les niveaux de maison ?',
    'MENU_TEXT_HOUSE_TIER_EXPLANATION_1': 'Le niveau de votre maison commence à 0. En construisant des meubles et en remplissant chaque pièce, le niveau de votre maison s\'améliorera.</span>',
    'MENU_TEXT_HOUSE_TIER_EXPLANATION_2': 'Lorsque toutes les pièces contiennent des meubles du niveau requis ou supérieur, le niveau de votre maison augmente. Vous débloquez des bonus de construction permanents et recevez des fournitures.',
    'MENU_TEXT_REWARDS': 'Récompenses',

    'SHOP_NAME_Construction_Skillcape': 'Cape de Chantier',

    'PET_NAME_ChuckTheForeman': 'Chuck le contremaître',
    'PET_NAME_Scoobs': 'Scoobs',


    'ITEM_NAME_Construction_Skillcape': 'Cape de Chantier',
    'ITEM_NAME_Builders_Hat': 'Chapeau de constructeur',
    'ITEM_NAME_Builders_Body': 'Carrosserie de constructeur',
    'ITEM_NAME_Builders_Leggings': 'Guêtres de constructeur',
    'ITEM_NAME_Builders_Boots': 'Bottes de constructeur',

    'ITEM_NAME_Iron_Nails': 'Clous en fer',
    'ITEM_NAME_Steel_Nails': 'Clous en acier',
    'ITEM_NAME_Mithril_Nails': 'Clous en mithril',
    'ITEM_NAME_Adamantite_Nails': 'Clous en adamante',
    'ITEM_NAME_Dragonite_Nails': 'Clous en draconite',

    'ITEM_NAME_Normal_Planks': 'Planches normales',
    'ITEM_NAME_Oak_Planks': 'Planches de chêne',
    'ITEM_NAME_Teak_Planks': 'Planches de teck',
    'ITEM_NAME_Mahogany_Planks': 'Planches d\'acajou',
    'ITEM_NAME_Magic_Planks': 'Planches magiques',

    'ITEM_NAME_Flower_Pots_Token_1': 'Pots de fleurs: Étage 1',
    'ITEM_NAME_Flower_Pots_Token_2': 'Pots de fleurs: Étage 2',
    'ITEM_NAME_Flower_Pots_Token_3': 'Pots de fleurs: Étage 3',
    'ITEM_NAME_Flower_Pots_Token_4': 'Pots de fleurs: Étage 4',
    'ITEM_NAME_Flower_Pots_Token_5': 'Pots de fleurs: Étage 5',


    'ITEM_DESCRIPTION_Builders_Hat': '+2% d\'XP de compétence de construction.<br><span class=\"text-warning\">Avec les quatre éléments de la tenue de constructeur équipés : + 8 % d\'XP de maîtrise de la construction.</span>',
    'ITEM_DESCRIPTION_Builders_Body': '+2% d\'XP de compétence de construction.<br><span class=\"text-warning\">Avec les quatre éléments de la tenue de constructeur équipés : + 8 % d\'XP de maîtrise de la construction.</span>',
    'ITEM_DESCRIPTION_Builders_Leggings': '+2% d\'XP de compétence de construction.<br><span class=\"text-warning\">Avec les quatre éléments de la tenue de constructeur équipés : + 8 % d\'XP de maîtrise de la construction.</span>',
    'ITEM_DESCRIPTION_Builders_Boots': '+2% d\'XP de compétence de construction.<br><span class=\"text-warning\">Avec les quatre éléments de la tenue de constructeur équipés : + 8 % d\'XP de maîtrise de la construction.</span>',

        'TOAST_FIXTURE_COMPLETE':'Vous avez terminé la construction de votre ${fixtureName}!',

    'MODIFIER_DATA_farmingTreeSeedReturn': '+${value}% de chances de récupérer une graine d\'arbre en agriculture lors de la récolte',
    'MODIFIER_DATA_decreaseConstructionActionsToUpgrade': '-${value}% d\'actions requises pour construire des meubles en Construction',
    'MODIFIER_DATA_increaseConstructionActionsToUpgrade': '+${value}% d\'actions requises pour construire des meubles en Construction',

    'DESCRIPTION_ADDS_ITEM': 'Donner ${itemQuantity} ${itemName} ${itemImage}',
    'DESCRIPTION_UNLOCKS_PLOT': 'Débloque 1 Parcelle ${plotCategory} en Agriculture',

    'TOASTS_MATERIALS_REQUIRED_TO_BUILD': 'Vous n\'avez pas les matériaux nécessaires pour construire cela.',

    'MASTERY_BONUS_ Construction_ 0': 'Débloquez les effets du niveau 1 du mobilier.',
    'MASTERY_BONUS_ Construction_ 1': 'Débloquez les effets du niveau 2 du mobilier.',
    'MASTERY_BONUS_ Construction_ 2': 'Débloquez les effets du niveau 3 du mobilier.',
    'MASTERY_BONUS_ Construction_ 3': 'Débloquez les effets du niveau 4 du mobilier.',
    'MASTERY_BONUS_ Construction_ 4': 'Débloquez les effets du niveau 5 du mobilier.',

    'SKILL_CATEGORY_ Construction_ Materials': 'Matériels',
    'SKILL_CATEGORY_ Construction_ House': 'Mobilier',

    'CONSTRUCTION_ROOM_NAME_ Bedroom': 'Chambre à coucher',
    'CONSTRUCTION_ROOM_NAME_ Garden': 'Jardin',
    'CONSTRUCTION_ROOM_NAME_ Kitchen': 'Cuisine',
    'CONSTRUCTION_ROOM_NAME_ Laboratory': 'Laboratoire',
    'CONSTRUCTION_ROOM_NAME_ Outpost': 'Avant-poste',
    'CONSTRUCTION_ROOM_NAME_ Refectory': 'Réfectoire',
    'CONSTRUCTION_ROOM_NAME_ Training_Room': 'Salle d\'entrainement',
    'CONSTRUCTION_ROOM_NAME_ Workshop': 'Atelier',

    'CONSTRUCTION_FIXTURE_OF_TIER': '${fixtureName}: Étage ${tier}',

    'CONSTRUCTION_FIXTURE_NAME_ Apparatus': 'Appareil',
    'CONSTRUCTION_FIXTURE_NAME_ Archery_Range': 'Champ de tir à l\'arc',
    'CONSTRUCTION_FIXTURE_NAME_ Black_Market': 'Marché noir',
    'CONSTRUCTION_FIXTURE_NAME_ Desk': 'Bureau',
    'CONSTRUCTION_FIXTURE_NAME_ Dragon_Statue': 'Statue de Dragon',
    'CONSTRUCTION_FIXTURE_NAME_ Fire_Pit': 'Foyer',
    'CONSTRUCTION_FIXTURE_NAME_ Flower_Pots': 'Pots de fleurs',
    'CONSTRUCTION_FIXTURE_NAME_ Forge': 'Forge',
    'CONSTRUCTION_FIXTURE_NAME_ Fridge': 'Garde-manger',
    'CONSTRUCTION_FIXTURE_NAME_ Jungle_Gym': 'Gymnase dans la jungle',
    'CONSTRUCTION_FIXTURE_NAME_ Lake': 'Lac',
    'CONSTRUCTION_FIXTURE_NAME_ Mines': 'Mine',
    'CONSTRUCTION_FIXTURE_NAME_ Orchard': 'Forêt',
    'CONSTRUCTION_FIXTURE_NAME_ Oven': 'Four',
    'CONSTRUCTION_FIXTURE_NAME_ Prayer_Altar': 'Autel de prière',
    'CONSTRUCTION_FIXTURE_NAME_ Rune_Altar': 'Autel runique',
    'CONSTRUCTION_FIXTURE_NAME_ Spell_Library': 'Bibliothèque de sorts',
    'CONSTRUCTION_FIXTURE_NAME_ Storage_Chest': 'Coffre de rangement',
    'CONSTRUCTION_FIXTURE_NAME_ Telescope': 'Télescope',
    'CONSTRUCTION_FIXTURE_NAME_ Tool_Rack': 'Boîte à outils',
    'CONSTRUCTION_FIXTURE_NAME_ Training_Dummy': 'Mannequin d\'entraînement',
    'CONSTRUCTION_FIXTURE_NAME_ Trapping_Hut': 'Cabane de piégeage',
    'CONSTRUCTION_FIXTURE_NAME_ Wardrobe': 'Garde-robe',
    'CONSTRUCTION_FIXTURE_NAME_ Worktable': 'Établi'
}    
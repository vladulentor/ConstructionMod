export const language = {
    'SKILL_NAME_Construction': '建設',

    'MENU_TEXT_SELECT_CONSTRUCTION_CATEGORY': '建設カテゴリを選択',
    'MENU_TEXT_CONSTRUCT': '構築する',
    'MENU_TEXT_BUILD': '建てる',
    'MENU_TEXT_BUILT_PROGRESS': 'アップグレード: ${currentValue}/${maxValue}',
    'MENU_TEXT_PARTIAL_BUILT_PROGRESS': '${currentValue}/${maxValue} ${percent}',
    'MENU_TEXT_SHOW_UPGRADES': 'アップグレード',
    'MENU_TEXT_SHOW_GO_BACK': '戻る',
    'MENU_TEXT_REMAINING': '残りのコスト',
    'MENU_TEXT_SHOW_ALL_ACTIVE_MODIFIERS': 'すべてのアクティブな修飾子を表示',
    'MENU_TEXT_ALL_ACTIVE_CONSTRUCTION_MODIFIERS': 'すべてのアクティブな建設修飾子',
    'MENU_VIEW_HOUSE_TIERS': 'ハウスティアボーナスを見る',
    'MENU_UNLOCKED_MASTERY_FOR_TIER': 'あなたの家ランクが<span class="construction-success">ランク ${tiername}</span>に上がりました',
    'MENU_HOUSE_TIER_BONUS_UNLOCKED': 'ハウスティアボーナスをアンロックしました！',
    'MENU_HOUSE_COMPLETION': 'ハウス完成度',
    'MENU_BUILT': '建造済み',
    'MENU_FIXTURES': '設備',

    'MENU_HOUSE': "家",
    'MENU_TIER': 'ランク ${tiername}',
    'MENU_TEXT_WHAT_ARE_HOUSE_TIERS': 'ハウスティアとは何ですか？',
    'MENU_TEXT_HOUSE_TIER_EXPLANATION_1': 'あなたの家のランクは0から始まります。家具を作り、各部屋を埋めることで、家のランクが向上します。</span>',
    'MENU_TEXT_HOUSE_TIER_EXPLANATION_2': 'すべての部屋に必要な階級以上の家具が揃うと、家のランクが上がります。恒久的な建築ボーナスが解除され、資材を獲得します。',
    'MENU_TEXT_REWARDS': '報酬',

    'SHOP_NAME_Construction_Skillcape': '建設スキルケープ',

    'PET_NAME_ChuckTheForeman': 'チャック・ザ・フォアマン',
    'PET_NAME_Scoobs': 'スクーブス',

    'ITEM_NAME_Construction_Skillcape': '建設スキルケープ',
    'ITEM_NAME_Builders_Hat': 'ビルダーハット',
    'ITEM_NAME_Builders_Body': 'ビルダーボディ',
    'ITEM_NAME_Builders_Leggings': 'ビルダーレギンス',
    'ITEM_NAME_Builders_Boots': 'ビルダーブーツ',

    'ITEM_NAME_Iron_Nails': '鉄釘',
    'ITEM_NAME_Steel_Nails': '鋼釘',
    'ITEM_NAME_Mithril_Nails': 'ミスリルの釘',
    'ITEM_NAME_Adamantite_Nails': 'アダマンタイトの釘',
    'ITEM_NAME_Dragonite_Nails': 'ドラゴナイトネイル',

    'ITEM_NAME_Normal_Planks': '通常の板',
    'ITEM_NAME_Oak_Planks': 'オークの板',
    'ITEM_NAME_Teak_Planks': 'チーク材の板',
    'ITEM_NAME_Mahogany_Planks': 'マホガニーの板',
    'ITEM_NAME_Magic_Planks': '魔法の板',

    'ITEM_NAME_Flower_Pots_Token_1': '植木鉢: 階層 1',
    'ITEM_NAME_Flower_Pots_Token_2': '植木鉢: 階層 2',
    'ITEM_NAME_Flower_Pots_Token_3': '植木鉢: 階層 3',
    'ITEM_NAME_Flower_Pots_Token_4': '植木鉢: 階層 4',
    'ITEM_NAME_Flower_Pots_Token_5': '植木鉢: 階層 5',


    'ITEM_DESCRIPTION_Builders_Hat': '建築スキル経験値 +2%<br><span class=\"text-warning\">ビルダーコスチューム4種すべてを着用している場合: 建設経験値 +8%</span>',
    'ITEM_DESCRIPTION_Builders_Body': '建築スキル経験値 +2%<br><span class=\"text-warning\">ビルダーコスチューム4種すべてを着用している場合: 建設経験値 +8%</span>',
    'ITEM_DESCRIPTION_Builders_Leggings': '建築スキル経験値 +2%<br><span class=\"text-warning\">ビルダーコスチューム4種すべてを着用している場合: 建設経験値 +8%</span>',
    'ITEM_DESCRIPTION_Builders_Boots': '建築スキル経験値 +2%<br><span class=\"text-warning\">ビルダーコスチューム4種すべてを着用している場合: 建設経験値 +8%</span>',

        'TOAST_FIXTURE_COMPLETE':'${fixtureName}の建造が完了しました！',

    
    'MODIFIER_DATA_farmingTreeSeedReturn': '農業で木の種を収穫すると、その種を再び入手できる確率が +${value}% 増加します',
    'MODIFIER_DATA_decreaseConstructionActionsToUpgrade': '-${value}% のアクションが必要：建設で家具を作る',
    'MODIFIER_DATA_increaseConstructionActionsToUpgrade': '+${value}% のアクションが必要：建設で家具を作る',

    'DESCRIPTION_ADDS_ITEM': '与える ${itemQuantity} ${itemName} ${itemImage}',
    'DESCRIPTION_UNLOCKS_PLOT': '農業で 1 つの ${plotCategory} 区画のロックを解除します',

    'TOASTS_MATERIALS_REQUIRED_TO_BUILD': 'それを作るのに必要な資材がない',

    'MASTERY_BONUS_ Construction_ 0': '家具のティア1効果をアンロックします。',
    'MASTERY_BONUS_ Construction_ 1': '家具のティア2効果をアンロックします。',
    'MASTERY_BONUS_ Construction_ 2': '家具のティア3効果をアンロックします。',
    'MASTERY_BONUS_ Construction_ 3': '家具のティア4効果をアンロックします。',
    'MASTERY_BONUS_ Construction_ 4': '家具のティア5効果をアンロックします。',

    'SKILL_CATEGORY_ Construction_ Materials': '材料',
    'SKILL_CATEGORY_ Construction_ House': '家具',

    'CONSTRUCTION_ROOM_NAME_ Bedroom': '寝室',
    'CONSTRUCTION_ROOM_NAME_ Garden': '庭',
    'CONSTRUCTION_ROOM_NAME_ Kitchen': '台所',
    'CONSTRUCTION_ROOM_NAME_ Laboratory': '研究室',
    'CONSTRUCTION_ROOM_NAME_ Outpost': '前哨基地',
    'CONSTRUCTION_ROOM_NAME_ Refectory': '食堂',
    'CONSTRUCTION_ROOM_NAME_ Training_Room': 'トレーニングルーム',
    'CONSTRUCTION_ROOM_NAME_ Workshop': 'ワークショップ',

    'CONSTRUCTION_FIXTURE_OF_TIER': '${fixtureName}: 階層 ${tier}',

    'CONSTRUCTION_FIXTURE_NAME_ Apparatus': '装置',
    'CONSTRUCTION_FIXTURE_NAME_ Archery_Range': 'アーチェリー場',
    'CONSTRUCTION_FIXTURE_NAME_ Black_Market': '闇市場',
    'CONSTRUCTION_FIXTURE_NAME_ Desk': 'デスク',
    'CONSTRUCTION_FIXTURE_NAME_ Dragon_Statue': '龍の像',
    'CONSTRUCTION_FIXTURE_NAME_ Fire_Pit': '火の穴',
    'CONSTRUCTION_FIXTURE_NAME_ Flower_Pots': '植木鉢',
    'CONSTRUCTION_FIXTURE_NAME_ Forge': 'フォージ',
    'CONSTRUCTION_FIXTURE_NAME_ Fridge': '食料庫',
    'CONSTRUCTION_FIXTURE_NAME_ Jungle_Gym': 'ジャングルジム',
    'CONSTRUCTION_FIXTURE_NAME_ Lake': '湖',
    'CONSTRUCTION_FIXTURE_NAME_ Mines': '鉱山',
    'CONSTRUCTION_FIXTURE_NAME_ Orchard': '森',
    'CONSTRUCTION_FIXTURE_NAME_ Oven': 'オーブン',
    'CONSTRUCTION_FIXTURE_NAME_ Prayer_Altar': '祈りの祭壇',
    'CONSTRUCTION_FIXTURE_NAME_ Rune_Altar': 'ルーン祭壇',
    'CONSTRUCTION_FIXTURE_NAME_ Spell_Library': 'スペルライブラリ',
    'CONSTRUCTION_FIXTURE_NAME_ Storage_Chest': '収納箱',
    'CONSTRUCTION_FIXTURE_NAME_ Telescope': '望遠鏡',
    'CONSTRUCTION_FIXTURE_NAME_ Tool_Rack': 'ツールボックス',
    'CONSTRUCTION_FIXTURE_NAME_ Training_Dummy': '訓練用ダミー',
    'CONSTRUCTION_FIXTURE_NAME_ Trapping_Hut': '捕獲小屋',
    'CONSTRUCTION_FIXTURE_NAME_ Wardrobe': 'ワードローブ',
    'CONSTRUCTION_FIXTURE_NAME_ Worktable': '作業台'
}
export const language = {
    'SKILL_NAME_Construction': 'Строительство',

    'MENU_TEXT_SELECT_CONSTRUCTION_CATEGORY': 'Выберите категорию строительства',
    'MENU_TEXT_CONSTRUCT': 'Построить',
    'MENU_TEXT_BUILD': 'Строить',
    'MENU_TEXT_BUILT_PROGRESS': 'Обновление: ${currentValue}/${maxValue}',
    'MENU_TEXT_PARTIAL_BUILT_PROGRESS': '${currentValue}/${maxValue} ${percent}',
    'MENU_TEXT_SHOW_UPGRADES': 'Обновления',
    'MENU_TEXT_SHOW_GO_BACK': 'Возвращаться',
    'MENU_TEXT_REMAINING': 'Оставшиеся расходы',
    'MENU_TEXT_SHOW_ALL_ACTIVE_MODIFIERS': 'Просмотреть все активные модификаторы',
    'MENU_TEXT_ALL_ACTIVE_CONSTRUCTION_MODIFIERS': 'Все активные модификаторы строительства',
    'MENU_VIEW_HOUSE_TIERS': 'Посмотреть бонусы уровня дома',
    'MENU_UNLOCKED_MASTERY_FOR_TIER': 'Уровень вашего дома повысился до <span class="construction-success">Уровня ${tiername}</span>',
    'MENU_HOUSE_TIER_BONUS_UNLOCKED': 'Бонус уровня дома разблокирован!',
    'MENU_HOUSE_COMPLETION': 'Завершение дома',
    'MENU_BUILT': 'Построено',
    'MENU_HOUSE': "Дом",
        'MENU_FIXTURES':'Фурнитура',

    'MENU_TIER': 'Уровень ${tiername}',
    'MENU_TEXT_WHAT_ARE_HOUSE_TIERS': 'Что такое уровни дома?',
    'MENU_TEXT_HOUSE_TIER_EXPLANATION_1': 'Уровень вашего дома начинается с 0. По мере того как вы строите мебель и заполняете каждую комнату, уровень вашего дома будет повышаться.</span>',
    'MENU_TEXT_HOUSE_TIER_EXPLANATION_2': 'Когда во всех комнатах будут мебель требуемого уровня или выше, уровень вашего дома повысится. Вы разблокируете постоянные бонусы к строительству и получите ресурсы.',
    'MENU_TEXT_REWARDS': 'Награды',

    'SHOP_NAME_Construction_Skillcape': 'Плащ Мастера: Строительство',

    'PET_NAME_ChuckTheForeman': 'Чак бригадир',
    'PET_NAME_Scoobs': 'Скубс',

    'ITEM_NAME_Construction_Skillcape': 'Плащ Мастера: Строительство',
    'ITEM_NAME_Builders_Hat': 'Шляпа строителя',
    'ITEM_NAME_Builders_Body': 'Жилет строителя',
    'ITEM_NAME_Builders_Leggings': 'Штаны строителя',
    'ITEM_NAME_Builders_Boots': 'Cапоги строителя',

    'ITEM_NAME_Iron_Nails': 'железные гвозди',
    'ITEM_NAME_Steel_Nails': 'стальные гвозди',
    'ITEM_NAME_Mithril_Nails': 'мифриловые гвозди',
    'ITEM_NAME_Adamantite_Nails': 'Адамантитовые гвозди',
    'ITEM_NAME_Dragonite_Nails': 'гвозди из драконита',

    'ITEM_NAME_Normal_Planks': 'Нормальные доски',
    'ITEM_NAME_Oak_Planks': 'Дубовые доски',
    'ITEM_NAME_Teak_Planks': 'Тиковые доски',
    'ITEM_NAME_Mahogany_Planks': 'доски из красного дерева',
    'ITEM_NAME_Magic_Planks': 'Волшебные доски',

    'ITEM_NAME_Flower_Pots_Token_1': 'Цветочные горшки: Уровень 1',
    'ITEM_NAME_Flower_Pots_Token_2': 'Цветочные горшки: Уровень 2',
    'ITEM_NAME_Flower_Pots_Token_3': 'Цветочные горшки: Уровень 3',
    'ITEM_NAME_Flower_Pots_Token_4': 'Цветочные горшки: Уровень 4',
    'ITEM_NAME_Flower_Pots_Token_5': 'Цветочные горшки: Уровень 5',


    'ITEM_DESCRIPTION_Builders_Hat': '+2 % к опыту навыка «Строительство».<br><span class=\"text-warning\">При экипировке всех четырех предметов одежды строителя: +8% к опыту строительного мастерства.</span>',
    'ITEM_DESCRIPTION_Builders_Body': '+2 % к опыту навыка «Строительство».<br><span class=\"text-warning\">При экипировке всех четырех предметов одежды строителя: +8% к опыту строительного мастерства.</span>',
    'ITEM_DESCRIPTION_Builders_Leggings': '+2 % к опыту навыка «Строительство».<br><span class=\"text-warning\">При экипировке всех четырех предметов одежды строителя: +8% к опыту строительного мастерства.</span>',
    'ITEM_DESCRIPTION_Builders_Boots': '+2 % к опыту навыка «Строительство».<br><span class=\"text-warning\">При экипировке всех четырех предметов одежды строителя: +8% к опыту строительного мастерства.</span>',

        'TOAST_FIXTURE_COMPLETE':'Вы завершили строительство {fixtureName}!',


    'MODIFIER_DATA_farmingTreeSeedReturn': '+${value}% кусок, чтобы восстановить семя дерева в сельском хозяйстве, когда собрано',
    'MODIFIER_DATA_decreaseConstructionActionsToUpgrade': '-${value}% действий требуется для создания мебели в Строительстве',
    'MODIFIER_DATA_increaseConstructionActionsToUpgrade': '+${value}% действий требуется для создания мебели в Строительстве',

    'DESCRIPTION_ADDS_ITEM': 'Дает ${itemQuantity} ${itemName} ${itemImage}',
    'DESCRIPTION_UNLOCKS_PLOT': 'Разблокирует 1 участок ${plotCategory} в разделе «Фермерство»',

    'TOASTS_MATERIALS_REQUIRED_TO_BUILD': 'У вас нет необходимых материалов для его постройки.',

    'MASTERY_BONUS_ Construction_ 0': 'Разблокируйте эффекты уровня 1 мебели.',
    'MASTERY_BONUS_ Construction_ 1': 'Разблокируйте эффекты уровня 2 мебели.',
    'MASTERY_BONUS_ Construction_ 2': 'Разблокируйте эффекты уровня 3 мебели.',
    'MASTERY_BONUS_ Construction_ 3': 'Разблокируйте эффекты уровня 4 мебели.',
    'MASTERY_BONUS_ Construction_ 4': 'Разблокируйте эффекты уровня % мебели.',

    'SKILL_CATEGORY_ Construction_ Materials': 'Материалы',
    'SKILL_CATEGORY_ Construction_ House': 'Мебель',

    'CONSTRUCTION_ROOM_NAME_ Bedroom': 'Спальня',
    'CONSTRUCTION_ROOM_NAME_ Garden': 'Сад',
    'CONSTRUCTION_ROOM_NAME_ Kitchen': 'Кухня',
    'CONSTRUCTION_ROOM_NAME_ Laboratory': 'Лаборатория',
    'CONSTRUCTION_ROOM_NAME_ Outpost': 'Форпост',
    'CONSTRUCTION_ROOM_NAME_ Refectory': 'Трапезная',
    'CONSTRUCTION_ROOM_NAME_ Training_Room': 'Тренировочная комната',
    'CONSTRUCTION_ROOM_NAME_ Workshop': 'Мастерская',

    'CONSTRUCTION_FIXTURE_OF_TIER': '${fixtureName}: Уровень ${tier}',

    'CONSTRUCTION_FIXTURE_NAME_ Apparatus': 'Аппарат',
    'CONSTRUCTION_FIXTURE_NAME_ Archery_Range': 'Стрельбище из лука',
    'CONSTRUCTION_FIXTURE_NAME_ Black_Market': 'Черный рынок',
    'CONSTRUCTION_FIXTURE_NAME_ Desk': 'Рабочий стол',
    'CONSTRUCTION_FIXTURE_NAME_ Dragon_Statue': 'Статуя дракона',
    'CONSTRUCTION_FIXTURE_NAME_ Fire_Pit': 'Яма для костра',
    'CONSTRUCTION_FIXTURE_NAME_ Flower_Pots': 'Цветочные горшки',
    'CONSTRUCTION_FIXTURE_NAME_ Forge': 'Кузница',
    'CONSTRUCTION_FIXTURE_NAME_ Fridge': 'Кладовая',
    'CONSTRUCTION_FIXTURE_NAME_ Jungle_Gym': 'Рама для лазания',
    'CONSTRUCTION_FIXTURE_NAME_ Lake': 'Озеро',
    'CONSTRUCTION_FIXTURE_NAME_ Mines': 'Рудник',
    'CONSTRUCTION_FIXTURE_NAME_ Orchard': 'Лес',
    'CONSTRUCTION_FIXTURE_NAME_ Oven': 'Печь',
    'CONSTRUCTION_FIXTURE_NAME_ Prayer_Altar': 'Молитвенный алтарь',
    'CONSTRUCTION_FIXTURE_NAME_ Rune_Altar': 'Рунический алтарь',
    'CONSTRUCTION_FIXTURE_NAME_ Spell_Library': 'Библиотека заклятий',
    'CONSTRUCTION_FIXTURE_NAME_ Storage_Chest': 'Ящик для хранения вещей',
    'CONSTRUCTION_FIXTURE_NAME_ Telescope': 'Телескоп',
    'CONSTRUCTION_FIXTURE_NAME_ Tool_Rack': 'Ящик для инструментов',
    'CONSTRUCTION_FIXTURE_NAME_ Training_Dummy': 'Манекен для обучения',
    'CONSTRUCTION_FIXTURE_NAME_ Trapping_Hut': 'Хижина-ловушка',
    'CONSTRUCTION_FIXTURE_NAME_ Wardrobe': 'Гардероб',
    'CONSTRUCTION_FIXTURE_NAME_ Worktable': 'Верстак'
}    

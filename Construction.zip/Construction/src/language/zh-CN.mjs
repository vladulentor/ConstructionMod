export const language = {
    'SKILL_NAME_Construction': '建造',

    'MENU_TEXT_SELECT_CONSTRUCTION_CATEGORY': '选择建筑类别',
    'MENU_TEXT_CONSTRUCT': '构造',
    'MENU_TEXT_BUILD': '建造',
    'MENU_TEXT_BUILT_PROGRESS': '升级: ${currentValue}/${maxValue}',
    'MENU_TEXT_PARTIAL_BUILT_PROGRESS': '${currentValue}/${maxValue} ${percent}',
    'MENU_TEXT_SHOW_UPGRADES': '升级',
    'MENU_TEXT_SHOW_GO_BACK': '回去',
    'MENU_TEXT_REMAINING': '剩余费用',
    'MENU_TEXT_SHOW_ALL_ACTIVE_MODIFIERS': '查看所有活动修改器',
    'MENU_TEXT_ALL_ACTIVE_CONSTRUCTION_MODIFIERS': '所有主动构造修饰符',
    'MENU_VIEW_HOUSE_TIERS': '查看房屋等级奖励',
    'MENU_UNLOCKED_MASTERY_FOR_TIER': '您的房屋等级已提升到 <span class="construction-success">等级 ${tiername}</span>',
    'MENU_HOUSE_TIER_BONUS_UNLOCKED': '房屋等级奖励已解锁！',
    'MENU_HOUSE_COMPLETION': '房屋完成度',
    'MENU_TIER': '等级 ${tiername}',
        'MENU_FIXTURES':'家具配件',

    'MENU_BUILT': '已建造',
    'MENU_HOUSE': "房子",

    'MENU_TEXT_WHAT_ARE_HOUSE_TIERS': '什么是房屋等级？',
    'MENU_TEXT_HOUSE_TIER_EXPLANATION_1': '您的房屋等级从0开始。随着您建造家具并填满每个房间，房屋等级会提升。</span>',
    'MENU_TEXT_HOUSE_TIER_EXPLANATION_2': '当所有房间都拥有所需等级或更高等级的家具时，您的房屋等级将提升。您将解锁永久建筑加成并获得材料。',
    'MENU_TEXT_REWARDS': '奖励',

    'SHOP_NAME_Construction_Skillcape': '建筑技能角',

    'PET_NAME_ChuckTheForeman': '主管查克',
    'PET_NAME_Scoobs': '斯库布斯',

    'ITEM_NAME_Construction_Skillcape': '建筑技能角',
    'ITEM_NAME_Builders_Hat': '建筑工人的帽子',
    'ITEM_NAME_Builders_Body': '建设者身体',
    'ITEM_NAME_Builders_Leggings': '建筑工人打底裤',
    'ITEM_NAME_Builders_Boots': '建设者靴子',

    'ITEM_NAME_Iron_Nails': '铁钉',
    'ITEM_NAME_Steel_Nails': '钢钉',
    'ITEM_NAME_Mithril_Nails': '秘銀',
    'ITEM_NAME_Adamantite_Nails': '精金钉',
    'ITEM_NAME_Dragonite_Nails': '龙石钉',

    'ITEM_NAME_Normal_Planks': '普通木板',
    'ITEM_NAME_Oak_Planks': '橡木板',
    'ITEM_NAME_Teak_Planks': '柚木板',
    'ITEM_NAME_Mahogany_Planks': '桃花心木板',
    'ITEM_NAME_Magic_Planks': '魔法木板',

    'ITEM_NAME_Flower_Pots_Token_1': '花盆: 层 1',
    'ITEM_NAME_Flower_Pots_Token_2': '花盆: 层 2',
    'ITEM_NAME_Flower_Pots_Token_3': '花盆: 层 3',
    'ITEM_NAME_Flower_Pots_Token_4': '花盆: 层 4',
    'ITEM_NAME_Flower_Pots_Token_5': '花盆: 层 5',


    'ITEM_DESCRIPTION_Builders_Hat': '建筑技能装备经验 +2% +2%<br><span class=\"text-warning\">当建造者套装的所有四件套都装备好时：建造精通经验值 +8%</span>',
    'ITEM_DESCRIPTION_Builders_Body': '建筑技能装备经验 +2% +2%<br><span class=\"text-warning\">当建造者套装的所有四件套都装备好时：建造精通经验值 +8%</span>',
    'ITEM_DESCRIPTION_Builders_Leggings': '建筑技能装备经验 +2% +2%<br><span class=\"text-warning\">当建造者套装的所有四件套都装备好时：建造精通经验值 +8%</span>',
    'ITEM_DESCRIPTION_Builders_Boots': '建筑技能装备经验 +2% +2%<br><span class=\"text-warning\">当建造者套装的所有四件套都装备好时：建造精通经验值 +8%</span>',

        'TOAST_FIXTURE_COMPLETE':'你已完成建造 ${fixtureName}!',


    'MODIFIER_DATA_farmingTreeSeedReturn': '+${value}% 收获时有机会在农业中重新获得树种',
    'MODIFIER_DATA_decreaseConstructionActionsToUpgrade': '-${value}% 动作用于在建造中制造家具',
    'MODIFIER_DATA_increaseConstructionActionsToUpgrade': '+${value}% 动作用于在建造中制造家具',

    'DESCRIPTION_ADDS_ITEM': '给出 ${itemQuantity} ${itemName} ${itemImage}',
    'DESCRIPTION_UNLOCKS_PLOT': '解锁 1 个 ${plotCategory} 农耕地块',

    'TOASTS_MATERIALS_REQUIRED_TO_BUILD': '你没有建造它所需的材料。',

    'MASTERY_BONUS_ Construction_ 0': '解锁家具的等级1效果。',
    'MASTERY_BONUS_ Construction_ 1': '解锁家具的等级2效果。',
    'MASTERY_BONUS_ Construction_ 2': '解锁家具的等级3效果。',
    'MASTERY_BONUS_ Construction_ 3': '解锁家具的等级4效果。',
    'MASTERY_BONUS_ Construction_ 4': '解锁家具的等级5效果。',

    'SKILL_CATEGORY_ Construction_ Materials': '材料',
    'SKILL_CATEGORY_ Construction_ House': '家具',

    'CONSTRUCTION_ROOM_NAME_ Bedroom': '卧室',
    'CONSTRUCTION_ROOM_NAME_ Garden': '花园',
    'CONSTRUCTION_ROOM_NAME_ Kitchen': '厨房',
    'CONSTRUCTION_ROOM_NAME_ Laboratory': '实验室',
    'CONSTRUCTION_ROOM_NAME_ Outpost': '前哨',
    'CONSTRUCTION_ROOM_NAME_ Refectory': '食堂',
    'CONSTRUCTION_ROOM_NAME_ Training_Room': '培训室',
    'CONSTRUCTION_ROOM_NAME_ Workshop': '车间',

    'CONSTRUCTION_FIXTURE_OF_TIER': '${fixtureName}: 层 ${tier}',

    'CONSTRUCTION_FIXTURE_NAME_ Apparatus': '设备',
    'CONSTRUCTION_FIXTURE_NAME_ Archery_Range': '射箭场',
    'CONSTRUCTION_FIXTURE_NAME_ Black_Market': '黑市',
    'CONSTRUCTION_FIXTURE_NAME_ Desk': '桌子',
    'CONSTRUCTION_FIXTURE_NAME_ Dragon_Statue': '龙雕像',
    'CONSTRUCTION_FIXTURE_NAME_ Fire_Pit': '火坑',
    'CONSTRUCTION_FIXTURE_NAME_ Flower_Pots': '花盆',
    'CONSTRUCTION_FIXTURE_NAME_ Forge': '锻造',
    'CONSTRUCTION_FIXTURE_NAME_ Fridge': '食品储藏室',
    'CONSTRUCTION_FIXTURE_NAME_ Jungle_Gym': '攀登架',
    'CONSTRUCTION_FIXTURE_NAME_ Lake': '湖',
    'CONSTRUCTION_FIXTURE_NAME_ Mines': '矿',
    'CONSTRUCTION_FIXTURE_NAME_ Orchard': '森林',
    'CONSTRUCTION_FIXTURE_NAME_ Oven': '烤箱',
    'CONSTRUCTION_FIXTURE_NAME_ Prayer_Altar': '祈祷坛',
    'CONSTRUCTION_FIXTURE_NAME_ Rune_Altar': '符文祭坛',
    'CONSTRUCTION_FIXTURE_NAME_ Spell_Library': '咒语库',
    'CONSTRUCTION_FIXTURE_NAME_ Storage_Chest': '储物箱',
    'CONSTRUCTION_FIXTURE_NAME_ Telescope': '望远镜',
    'CONSTRUCTION_FIXTURE_NAME_ Tool_Rack': '工具箱',
    'CONSTRUCTION_FIXTURE_NAME_ Training_Dummy': '训练假人',
    'CONSTRUCTION_FIXTURE_NAME_ Trapping_Hut': '诱捕小屋',
    'CONSTRUCTION_FIXTURE_NAME_ Wardrobe': '衣柜',
    'CONSTRUCTION_FIXTURE_NAME_ Worktable': '工作台'
}    
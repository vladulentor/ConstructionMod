const { loadModule } = mod.getContext(import.meta);

const { tierArray } = await loadModule('src/patches/skillPatches/atlasofdiscovery/archaeology/tierarray.mjs');

const { unlockPlot } = await loadModule('src/patches/skillPatches/farming/unlockPlot.mjs');

const { patchWorldMap } = await loadModule("src/patches/skillPatches/atlasofdiscovery/patchWorldMap.mjs");

const { addFoodSlot } = await loadModule("src/patches/skillPatches/combat/addFoodSlot.mjs");

const { doubleEffectsOfStuff } = await loadModule("src/patches/skillPatches/cooking/doubleEffectsOfStuff.mjs");

const { upgradeRegenPotions } = await loadModule("src/patches/skillPatches/herblore/upgradeRegenPotions.mjs");
const { upgradeFirePotions } = await loadModule("src/patches/skillPatches/herblore/upgradeFirePotions.mjs");


const { multiplyRoaringEffects } = await loadModule("src/patches/skillPatches/firemaking/multiplyRoaringEffects.mjs");
const { addSaplingBranchDrop } = await loadModule("src/patches/skillPatches/firemaking/addSaplingBranchDrop.mjs");




export const EffectRegistry = {
  tierArray,
  unlockPlot,
  patchWorldMap,
  addFoodSlot,
  upgradeRegenPotions,
  doubleEffectsOfStuff,
  upgradeFirePotions,
  multiplyRoaringEffects,
  addSaplingBranchDrop
};

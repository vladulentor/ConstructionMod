export function addShopPurchases(){

    
}